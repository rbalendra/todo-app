package nology.io.todo.todo;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.graphql.GraphQlProperties.Http;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import com.github.javafaker.Cat;

import groovy.transform.AutoClone;
import io.restassured.RestAssured;
import nology.io.todo.category.Category;
import nology.io.todo.category.CategoryRepository;


import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import io.restassured.http.ContentType;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class CategoryEndToEndTest {
    
    @LocalServerPort
    private int port;

    @Autowired
    private CategoryRepository categoryRepository;

    private ArrayList<Category> categories = new ArrayList<>(); // list to store categories for testing

    @BeforeEach
    public void setUp() {
        RestAssured.port = port; // sets the port for RestAssured to use

        this.categoryRepository.deleteAll(); // clear the database before each test
        this.categories.clear(); // clear the list of categories before each test

        Category category1 = new Category();
        category1.setName("Work");
        this.categoryRepository.save(category1);
        this.categories.add(category1); // store the first category in the list

        Category category2 = new Category();
        category2.setName("Personal");
        this.categoryRepository.save(category2);
        this.categories.add(category2); // store the second category in the list

        }
        /* ---------------------------- Test for Get all ---------------------------- */
        @Test
        public void getAllCategories_CategoriesInDB_ReturnsSuccess() {
                    given()
                    .when()
                    .get("/categories")
                    .then()
                    .statusCode(200)
                    .body("size()", is(categories.size())) // check the size of the response
                    .body("name", hasItems("Work", "Personal")); // check if the names are present in the response

        }
    
        /* ----------------------------- Test for GET all /categories with empty db  ----------------------------- */
     
        @Test
        public void getAllCategories_EmptyDB_ReturnsEmptyList() {
            this.categoryRepository.deleteAll(); // ensure the database is empty

                     given()
                    .when()
                    .get("/categories")
                    .then()
                    .statusCode(200)
                    .body("size()", is(0)); // check if the response is an empty list
        }

        /* ------------------- Test for invalid ID for CategoryID ------------------- */
        // @Test
        // public void getCategoryById_InvalidID_BadRequest() {
       
        //             given()
        //             .when()
        //             .get("/categories/abcd")
        //             .then()
        //             .statusCode(HttpStatus.BAD_REQUEST.value());
         
        // }

}
