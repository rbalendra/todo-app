package nology.io.todo.todo;

import java.time.LocalDate;
import java.util.ArrayList;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import io.restassured.RestAssured;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import nology.io.todo.todos.Todo;
import nology.io.todo.todos.TodoRepository;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) // app to start running on random port
@ActiveProfiles("test")
public class TodoEndToEndTest {

    @LocalServerPort // injects the random port assigned to the application
    private int port;

    @Autowired
    private TodoRepository todoRepository;

    private ArrayList<Todo> todos = new ArrayList<>();

    @BeforeEach
    public void setUp() {
        RestAssured.port = port; // sets the port for RestAssured to use

        this.todoRepository.deleteAll(); // clear the database before each test
        this.todos.clear(); // clear the list of todos before each test

        // set up some data and save it in the database
        Todo todo1 = new Todo();
        todo1.setName("buy a book");
        todo1.setDueDate(LocalDate.of(2025, 6, 16));
        todo1.setCompleted(false);
        this.todoRepository.save(todo1);
        this.todos.add(todo1); // store the first todo in the list

        Todo todo2 = new Todo();
        todo2.setName("buy a pen");
        todo2.setDueDate(LocalDate.of(2025, 6, 16));
        todo2.setCompleted(false);
        this.todoRepository.save(todo2);
        this.todos.add(todo2); // store the second todo in the list

    }

    /* ---------------------- Test for GET all /todos endpoint ---------------------- */
    @Test
    public void getAllTodos_TodosInDB_ReturnsSuccess() {
        //Arrange is already done in setUp()
        //Act
        //Assert
        given().when().get("/todos").then().statusCode(HttpStatus.OK.value()).body("$", hasSize(2)).body("name",
                hasItems("buy a book", "buy a pen"))
                .body(matchesJsonSchemaInClasspath("schemas/todo-list-schema.json"));

    }
    
    /* ---------------- Test for GET all /todos with empty db ---------------- */
    @Test
    public void getAllTodos_NoTodosInDB_ReturnsSuccessAndEmptyArray() {
        this.todoRepository.deleteAll();
        given()
                .when().get("/todos")
                .then().statusCode(HttpStatus.OK.value())
                .body("$", hasSize(0));

    }

 /* ---------------------- Test for invalid ID for todos --------------------- */
    @Test
    public void getById_InvalidId_BadRequest() {
        given().when().get("/todos/abcd").then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    /* ------------------------ if ID not in the database ----------------------- */
    @Test
    public void getById_IdNotInDB_NotFound() {
        Long largeID = 99999l;

        given()
                .when()
                .get("/todos/" + largeID)
                .then()
                .statusCode(HttpStatus.NOT_FOUND.value());
    }
    
}
