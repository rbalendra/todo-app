package nology.io.todo.common.exceptions;


public class NotFoundException extends Exception {
    
    public NotFoundException(String message) {
        super(message);
    }
    
}
